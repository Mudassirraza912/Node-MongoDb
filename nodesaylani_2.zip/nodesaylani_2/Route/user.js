const express =require ("express")
const router = express.Router()

router.use("/getAll/:id",(req, res) => {
    console.log("REQ PARAM",req.params)
})

module.exports = router