const express = require('express');
const app = express();

app.listen(3000,()=>{
    console.log('server connected to local host')
});

app.use('/user',(request,response)=>{
    console.log('user request')
    response.send({name:'talha', age:24})
})

app.get('/user',(request,response)=>{
    console.log('user request',request.query);
    response.send({name:'talha', age:24})
})

app.use('/',require('./Route/index'))